"""Read-only live version/parameter/capability check. Never arm, change mode, or write parameters."""
import argparse
import json
from pathlib import Path
import sys
import time
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from bluerov2.force_run import load_config, DEFAULT_CONFIG
from bluerov2.host_tracking import load_backend
from bluerov2.thruster_output import controller_class,encode_frame,QUERY
from bluerov2.hardware_check import _collect_dvl


def main():
    p=argparse.ArgumentParser();p.add_argument('--config',type=Path,default=DEFAULT_CONFIG);p.add_argument('--output',type=Path,default=Path('reports/live_diagnosis.json'))
    a=p.parse_args();cfg=load_config(a.config);backend=load_backend(cfg['legacy_directory']);old=backend.load_config(Path(cfg['legacy_config']))
    Path(cfg['log_directory']).mkdir(parents=True,exist_ok=True)
    logger=backend.SessionLogger(Path(cfg['log_directory']),action='direct6_read_only_diagnosis')
    c=controller_class(backend)(old['connection'],old['baud'],old['source_system'],cfg['source_component'],old.get('target_system'),old.get('target_component'),logger,3.,2.,3.)
    report={'read_only':True,'actuator_commands_sent':False,'configured_endpoint':old['connection'],'query_protocol':{'carrier':'DATA64','type':214,'length':34}}
    try:
        c.connect();mav=c.master.mav
        report.update(target=[c.target_system,c.target_component],armed=c.vehicle.armed,mode=c.vehicle.mode)
        mav.command_long_send(c.target_system,c.target_component,520,0,1,0,0,0,0,0,0)
        parameter_names=list(cfg['required_parameters'])+['SYSID_MYGCS','FS_PILOT_INPUT','FS_PILOT_TIMEOUT']+[f'SERVO{i}_{field}' for i in range(1,7) for field in ('MIN','MAX','TRIM','REVERSED')]+[f'MOT_{i}_DIRECTION' for i in range(1,7)]
        for name in dict.fromkeys(parameter_names):
            mav.param_request_read_send(c.target_system,c.target_component,name.encode(),-1)
        mav.data64_send(0xD6,34,list(encode_frame(QUERY,(c.target_system,c.target_component))))
        end=time.monotonic()+3
        while time.monotonic()<end:c.service_io();time.sleep(.005)
        v=c.vehicle.autopilot_version
        report['autopilot_version']=v
        if v.get('flight_sw_version') is not None:
            n=int(v['flight_sw_version']);report['version']=[(n>>24)&255,(n>>16)&255,(n>>8)&255]
        report['parameters']=c.vehicle.parameters
        report['direct6_status']=c.direct_status
        if 'SERVO_OUTPUT_RAW' in c.state_messages:
            msg=c.state_messages['SERVO_OUTPUT_RAW'][1]
            report['observed_pwm_us']=[getattr(msg,f'servo{i}_raw') for i in range(1,7)]
        if 'SYS_STATUS' in c.state_messages:
            report['voltage_battery_mv']=c.state_messages['SYS_STATUS'][1].voltage_battery
    except Exception as exc:report['error']=f'{type(exc).__name__}: {exc}'
    finally:c.close();logger.close()
    report['dvl']=_collect_dvl(old['dvl_ip'],old['dvl_port'],1.,.25)
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
