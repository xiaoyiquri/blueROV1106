"""Exercise the compiled patched ArduSub in an owned, isolated localhost SITL.
No live endpoint argument is accepted. No firmware is uploaded.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import secrets
import subprocess
import sys
import tempfile
import time
import traceback

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from bluerov2.thruster_output import encode_frame, decode_status, QUERY,ACQUIRE,FRAME,STOP,RELEASE
from bluerov2.thruster_output import ThrusterOutput,controller_class
from bluerov2.force_run import DEFAULT_CONFIG,load_config,jsonable
from bluerov2.host_tracking import load_backend
from bluerov2.t200 import T200
from pymavlink import mavutil

NEUTRAL=[1500]*6
PORT=15760


class Link:
    def __init__(self, master):
        self.master=master;self.status=None;self.heartbeat=None;self.trace=[]
        self.session=secrets.randbelow(2**32-1)+1;self.sequence=0
        self.held=NEUTRAL;self.maintain=False;self.next_frame=0.;self.next_hb=0.

    def send(self,op,pwm=NEUTRAL):
        # Match the production transport: never extrapolate the FC clock using host time.
        fc_ms=0 if self.status is None else self.status['fc_ms']
        self.sequence+=1
        payload=encode_frame(op,(1,1),self.session,self.sequence,fc_ms+200,pwm)
        self.master.mav.data64_send(0xD6,34,list(payload))

    def poll(self):
        while True:
            msg=self.master.recv_match(blocking=False)
            if msg is None:break
            if msg.get_srcSystem()!=1 or msg.get_srcComponent()!=1:continue
            if msg.get_type()=='DATA64' and msg.type==0xD6:
                s=decode_status(msg.data)
                if s:self.status={**s,'received_mono':time.monotonic()};self.trace.append(self.status.copy())
            if msg.get_type()=='HEARTBEAT':self.heartbeat=msg
        now=time.monotonic()
        if now>=self.next_hb:
            self.master.mav.heartbeat_send(6,8,0,0,4);self.next_hb=now+1.
        if self.maintain and now>=self.next_frame:
            self.send(FRAME,self.held);self.next_frame=now+.04

    def wait(self,predicate,timeout=3.):
        until=time.monotonic()+timeout
        while time.monotonic()<until:
            self.poll()
            if predicate():return
            time.sleep(.002)
        raise AssertionError('SITL condition timed out')

    def spin(self,duration):
        end=time.monotonic()+duration
        while time.monotonic()<end:self.poll();time.sleep(.002)

    def query(self):
        old=self.status
        self.send(QUERY)
        self.wait(lambda:self.status is not old)
        return self.status

    def arm(self,armed):
        self.master.mav.command_long_send(1,1,400,0,int(armed),0,0,0,0,0,0)
        self.wait(lambda:self.heartbeat is not None and bool(self.heartbeat.base_mode&128)==armed)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--binary',type=Path,required=True)
    p.add_argument('--output',type=Path,default=Path('reports/direct6_sitl.json'))
    a=p.parse_args();binary=a.binary.resolve()
    report={'created_utc':datetime.now(timezone.utc).isoformat(),'binary':str(binary),
            'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),
            'localhost_only':True,'physical_vehicle_used':False,'checks':{},'all_checks_passed':False}
    checks=report['checks'];link=None;master=None;proc=None
    a.output.parent.mkdir(parents=True,exist_ok=True)
    log=a.output.with_suffix('.console.log')
    try:
        with tempfile.TemporaryDirectory(prefix='direct6-sitl-') as work,log.open('w') as console:
            defaults=Path(work)/'defaults.parm'
            defaults.write_text('FRAME_CONFIG 1\nARMING_CHECK 0\nSYSID_MYGCS 255\nFS_GCS_ENABLE 0\nFS_PILOT_INPUT 0\n')
            cmd=[str(binary),'-w','--model','vectored','--home=-35.363261,149.165230,0,0',
                 '--base-port',str(PORT),'--defaults',str(defaults)]
            report['command']=cmd
            proc=subprocess.Popen(cmd,cwd=work,stdout=console,stderr=subprocess.STDOUT)
            # Connect only to the process created above, never to the real robot UDP link.
            end=time.monotonic()+12
            while True:
                if proc.poll() is not None:raise RuntimeError('SITL exited before accepting TCP')
                try:
                    master=mavutil.mavlink_connection(f'tcp:127.0.0.1:{PORT}',source_system=255,source_component=191)
                    break
                except OSError:
                    if time.monotonic()>end:raise
                    time.sleep(.1)
            link=Link(master);link.wait(lambda:link.heartbeat is not None,10.)
            master.mav.set_mode_send(1,1,19)
            link.spin(1.2)
            status=link.query()
            assert status['state']==0 and status['ready'] and not status['armed']
            checks['query_idle_disarmed_ready']=True
            link.sequence=0;link.send(ACQUIRE)
            link.wait(lambda:link.status['state']==1 and link.status['session']==link.session)
            link.maintain=True;link.arm(True)
            checks['acquire_and_arm_neutral']=True
            pwm=[1540,1460,1550,1450,1560,1440]
            link.held=pwm;link.spin(.15)
            assert link.status['state']==1 and link.status['driver_readback_pwm_us']==pwm
            checks['complete_six_outputs_reach_hal']=True
            # Real legacy MAVLink commands are sent to SITL to test firmware isolation.
            master.mav.manual_control_send(1,1000,1000,1000,1000,0)
            master.mav.set_mode_send(1,1,4)
            master.mav.command_long_send(1,1,183,0,1,1900,0,0,0,0,0)
            master.mav.command_long_send(1,1,209,0,1,0,50,1,0,0,0)
            master.mav.set_position_target_local_ned_send(0,1,1,1,0x0ff8,1,2,3,0,0,0,0,0,0,0,0)
            link.spin(.3)
            assert link.status['state']==1 and link.status['driver_readback_pwm_us']==pwm
            assert link.heartbeat.custom_mode==19
            checks['legacy_manual_guided_servo_motor_test_do_not_overwrite']=True
            original=master.mav.srcSystem
            master.mav.srcSystem=254;link.send(ACQUIRE);master.mav.srcSystem=original
            link.spin(.1)
            assert link.status['owner']==(255,191) and link.status['state']==1
            checks['second_owner_refused']=True
            # Stop only control FRAME transmission. No Python stop/finally is invoked here.
            link.maintain=False;link.poll()
            last=link.status.copy();until=time.monotonic()+.4
            observed=None
            while time.monotonic()<until:
                status=link.query()
                if status['state']==2 and status['driver_readback_pwm_us']==NEUTRAL:
                    observed=status;break
                # A previously sent frame may still be in flight when refresh stops.
                # Use the final accepted deadline reported by firmware.
                if status['state']==1:last=status.copy()
                time.sleep(.005)
            assert observed is not None
            extra=observed['fc_ms']-(last['fc_ms']+last['remaining_ms'])
            assert 0 <= extra <= 60
            report['watchdog_neutral_observation_after_deadline_ms']=extra
            checks['firmware_watchdog_neutral_without_host_stop']=True
            link.send(FRAME,pwm);link.spin(.04)
            assert link.query()['state']==2 and link.status['driver_readback_pwm_us']==NEUTRAL
            checks['late_frame_cannot_resume_after_fault']=True
            link.send(STOP);link.arm(False);link.send(RELEASE)
            link.wait(lambda:link.status['state']==0 and not link.status['armed'])
            assert link.status['driver_readback_pwm_us']==NEUTRAL
            checks['neutral_disarm_release_confirmed']=True
            # The deliberate legacy-injection test above sets the firmware quiet timer.
            # A new session must satisfy the documented >1 s idle-input condition.
            link.spin(1.1)
            # Test the production Python force mapper, heartbeat handling and stop
            # against the same full firmware process; only the in-memory SITL config is enabled.
            cfg=load_config(DEFAULT_CONFIG);backend=load_backend(cfg['legacy_directory'])
            logger=backend.SessionLogger(a.output.parent/'sitl_session_logs',action='direct6_sitl')
            ctrl=controller_class(backend)(f'tcp:127.0.0.1:{PORT}',115200,255,191,1,1,logger,5.,3.,3.)
            ctrl.master=master;ctrl.vehicle.target_system=ctrl.vehicle.target_component=1
            ctrl.process_message(link.heartbeat)
            output_config={**cfg['output'],'firmware_verified':True,'channel_mapping_verified':True,
                           'lock_file':str(Path(work)/'output.lock'),'test_voltage_v':16.}
            output=ThrusterOutput(ctrl,T200(cfg['mapping'],cfg['curve_file']),output_config,
                                  lambda kind,**data:logger.write_log(kind,**jsonable(data)))
            try:
                output.prepare()
                assert ctrl.vehicle.armed is True and ctrl.direct_status['armed']
                checks['production_prepare_waits_for_fresh_armed_heartbeat']=True
                output.set_interval_deadline(time.monotonic()+.4)
                mapped=output.send_thruster_forces([1.,-1.,2.,-2.,1.5,-1.5])
                end=time.monotonic()+.2
                while time.monotonic()<end:output.poll();time.sleep(.003)
                assert ctrl.direct_status['driver_readback_pwm_us']==list(mapped['pwm_us'])
                checks['production_forces_to_t200_pwm_to_full_firmware_hal']=True
                report['production_mapping']=jsonable(mapped)
            finally:
                report['production_stop']=jsonable(output.stop());logger.close()
            assert report['production_stop']['confirmed']
            checks['production_stop_confirms_neutral_disarm_release']=True
            report['all_checks_passed']=True
    except Exception as exc:
        report['error']=f'{type(exc).__name__}: {exc}'
        report['traceback']=traceback.format_exc()
    finally:
        if master is not None:master.close()
        if proc is not None and proc.poll() is None:
            proc.terminate()
            try:proc.wait(timeout=5)
            except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=3)
        if link is not None:
            trace=a.output.with_suffix('.status.jsonl')
            trace.write_text(''.join(json.dumps(row)+'\n' for row in link.trace))
            report['status_trace']=str(trace)
        a.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(report,ensure_ascii=False,indent=2))
    return 0 if report['all_checks_passed'] else 1


if __name__=='__main__':raise SystemExit(main())
