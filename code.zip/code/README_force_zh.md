本次交付为现有六推进器 Python 项目新增独立的“轨迹推力执行”入口，入口是 `python3 -m bluerov2.force_run`。规划、搜索、代价、协方差传播及反馈控制文件没有为本任务修改；推力执行继续使用 `bluerov2.execution.execute_lbts_plan` 的原反馈计算和启动/运行误差检查。原 goto、主机 PD、MANUAL_CONTROL 功能保留。

**当前验收状态：软件链路已实现并测试；真实六路输出和轨迹跟踪尚未完成。** 只读诊断核实当前 ArduSub 3.5.4 没有新增接口，DVL、飞控 IMU 和外置 GV7 已只读接通，但状态时间差/年龄多次超限；原 Python 模型还存在已标记的推进器坐标/FRD 标签冲突。完整 ArduSub SITL 及实际 Python 接口 11/11 联测通过；真机仍缺独立输出固件，程序拒绝实机输出。最新证据和全部阻塞项见 [本轮验证报告](reports/VALIDATION_zh.md)。指定附件路径 `/home/tj/blueROV2/目录` 不存在，本次以实际 `/home/tj/blueROV2/code` 六推进器项目和上级真实通信代码为基础。

**算法对齐没有全部通过。** 原 `.m` 数值源码已通过隔离的 GNU Octave 6.4.0 运行，与 Python 比较。26 项中 25 项通过；同一组样本下机会约束概率存在 0.090/0.085 差异。没有擅自修复算法，详见本文算法验证说明及 `reports/proposed_chance_alignment.patch`。MATLAB 本体、原 MATLAB CasADi/IPOPT 和完整规划搜索尚未运行。

交付文件

| 文件 | 内容 |
|---|---|
| `bluerov2/state_adapter.py` | DVL 固定位姿/速度 + 飞控机体系角速度 → 十二维状态 |
| `bluerov2/t200.py` | 官方离线曲线，分别正反向、按电压插值 |
| `bluerov2/thruster_output.py` | `send_thruster_forces` / `send_thruster_pwm`，完整六路协议、停止确认 |
| `bluerov2/force_run.py` | 算法计划和有限时长 PWM 测试入口、计划导出元数据、实验报告/图 |
| `bluerov2/data/force_config.json` | 路径、映射、状态变换、电压、调度阈值、输出核验状态 |
| `bluerov2/data/*.xlsx`、`t200_curves.json` | 官方原始数据和离线预处理数据 |
| `tools/preprocess_t200.py` | 用标准 ZIP/XML 库完整读取 Excel，重现预处理，无 openpyxl 依赖 |
| `tools/verify_connected.py`、`verify_direct6_sitl.py` | 只读三路采集/时序核查，以及完整本机飞控进程联测 |
| `tools/diagnose_direct6.py` | 只读版本/参数/六路中立/能力/DVL 诊断，不发送执行器指令 |
| `tools/verify_matlab_alignment.py`、`alignment_reference.m` | 可重复的原 MATLAB 数值源码对齐验证 |
| `firmware/ardusub_3_5_4/` | 精确版本的源码补丁、协议说明、共享 C++ 核心和测试 |
| `tests/test_force_output.py`、`test_force_state.py` | 新链路、原反馈、时序、原生固件核心、状态与停止回归测试 |
| `reports/` | 本轮只读诊断、算法差异和实际测试记录 |

安装和两类命令

```bash
cd /home/tj/blueROV2/code
python3 -m pip install -e '.[hardware,test]'
python3 -m bluerov2.force_run --help
```

普通命令默认**离线检查**，不会打开机器人连接、请求模式或解锁。硬件命令仅增加一次 `--execute`，不弹出反复确认，也不自动刷固件/修改参数。

```bash
# 1. 算法计划：先离线检查，再在所有核验完成后显式执行
python3 -m bluerov2.force_run --output reports/plan_check.json plan experiment.pkl
python3 -m bluerov2.force_run --output reports/experiment.json plan experiment.pkl --execute

# 2. 六路 PWM：参数按物理 MAIN1..MAIN6，最多 5 秒
python3 -m bluerov2.force_run --output reports/pwm_check.json pwm-test --pwm 1500 1500 1500 1500 1500 1500 --duration 0.5
python3 -m bluerov2.force_run --output reports/pwm_test.json pwm-test --pwm 1540 1500 1500 1500 1500 1500 --duration 0.5 --execute
```

16V官方死区约1472～1528μs，因此±20μs可能没有可辨别推力；示例1540μs位于正向死区外，反向可用1460μs逐路测试。上面的非中立示例仅用于完成固件构建/测量和水中逐路验证后的显式测试；当前配置下实机入口会拒绝。PWM 测试不依赖 DVL 和推力方向核验，它正是用于核验通道与方向的；仍要求固件接口、实时版本、参数、已上锁状态及完整停止确认。轨迹推力额外要求模型、坐标和状态来源已核验。

计划的实际格式与导出

继续使用现有 `bluerov2.io.save_result` 的 `bluerov2-python-result-v1` pickle，包含原始 `ModelParameters` 和所有算法结果，不手工重排长轨迹。不读取旧八推进器 MAT 缓存。只加载自己生成、可信的 pickle；Python pickle 是对象格式，不能当作不可信交换格式。

| 字段 | 维度/意义 |
|---|---|
| `success` | 原算法的成功结果 |
| `nominalTrajectory` | `(12,N+1)`；`[N,E,D,roll,pitch,yaw,u,v,w,p,q,r]` |
| `controlTrajectory` | `(6,N)`；各推进器标称推力 N |
| `feedbackGains` | 长度 N；每个 `(6,12)`，原算法增益 |
| `time` | `(N+1,)`；秒，从 0 开始严格递增，可非等间隔 |
| `model`、`world` | 原算法模型和世界约束 |
| `execution_reference` | 导出函数附加单位、固定参考摘要、模型摘要；不会修改轨迹 |

在原规划调用成功获得 `result` 后，用以下函数替换保存调用：

```python
from bluerov2.force_run import save_force_plan

# 前提：生成 result 时使用的就是 task_origin.json 定义的固定任务坐标。
# 此函数只附加元数据，不会把地理 NED 或其他原点的结果自动变换过来。
save_force_plan('experiment.pkl', result, '/home/tj/blueROV2/task_origin.json')
```

现有结果可先用 `load_result` 读取后调用同一函数，但必须知道该结果的真实坐标基准。元数据不能把不一致的轨迹变成可执行轨迹；若旧计划使用其他原点/朝向，先按原算法接口在本任务坐标中生成，不能简单盖上摘要。示例演示计划通常不是实机原点的轨迹。

离线检查复用原执行器检查维度、时间、有限数值、速度及自由空间；实机准备阶段额外检查原起点位置/姿态/线速度/角速度条件、实际电压下标称推力能力、实时固件及参数、完整状态与输出能力。计划标称推力超算法或硬件范围直接拒绝，反馈超硬件能力也直接终止，不用大范围裁剪掩盖不可执行性。

状态来源与固定参考

本次不切换定位方案、不重复 EKF。没有 `LOCAL_POSITION_NED` 时，复用上级项目有效使用过的 `DvlFeed` 和 `parse_dead_reckoning`：

| 状态 | 来源 | 转换 |
|---|---|---|
| 位置 | A50 航位推算 x/y/z | `R_world @ p_dvl - saved_origin - R_world_body @ lever`，m |
| roll/pitch/yaw | A50 航位推算姿态 | 原始度 → rad；使用完整安装/世界旋转组合，再提取 ZYX |
| u/v/w | A50 vx/vy/vz | 默认 native sensor；撤销旧 feed 已做的矩阵后只应用一次传感器→机体旋转，并补偿已配置的杆臂转动速度 |
| p/q/r | 飞控 `ATTITUDE.rollspeed/pitchspeed/yawspeed` | 原版固件发送的是 `ahrs.get_gyro()`；单位 rad/s，机体系角速度，直接使用 |

若已经确认速度在 DVL 固定世界系，将 `state.velocity_frame` 设为 `dvl_world`，按同一完整姿态转入机体系；不能对 native 机体系速度重复世界旋转。原 feed 的同一矩阵曾同时用于位置和速度，本适配器明确区分世界与安装旋转，避免继承该含糊语义。

上级 `task_origin.json` 保存的是位置平移 `origin`、安装矩阵和航向目标 `yaw_target_rad`。**文件写入不执行设备 Reset，也不重置飞控 Home/EKF。** 上级说明记录 A50 Reset dead reckoning 会重设设备航位推算位置及姿态参考；这属于设备操作，当前连接已恢复，但现有参考文件没有设备 Reset 标识，无法仅凭一次静态采样核实最后复位时刻。此次代码不发送任何 reset/calibration 命令，不要求每次从水面重新建原点。

`local_at_dvl_reset` 是初始航向对齐后固定的右手世界系，不凭“复位”就成为地理北东；状态中的 N/E 在这里是沿用算法的第 1/2 轴名称。`world_from_dvl_world` 必须与保存原点的任务变换相同。机体系 FRD 的方向由独立的 `body_from_dvl_sensor` 定义，杆臂 `body_to_dvl_m` 为机体参考点指向 DVL 的机体向量。

新适配器不会把上级 PD 的 `yaw_target_rad` 再次扣成零航向：上级原点文件只平移位置，而航向目标是控制时保持的角度；对姿态单独减去它、位置仍不旋转会产生不一致。算法轨迹必须使用同一个固定 DVL 世界基准的姿态和位置。若需要以保存航向为新世界轴，必须统一变换位置、姿态和速度，不能仅调整 yaw；本次没有擅自这么做。

每次返回包含 `state/valid/age/timestamp/component_age_s/receipt_skew_s/device_timestamp/reference_id`。必要分量缺失时返回 NaN 且 `valid=False`，绝不补零标有效。状态和持有区间内均检查：最长接收年龄 0.25 s、分量接收时间差 0.15 s、心跳、设备时钟倒退/不再前进、位置/姿态跳变、固定参考文件摘要。首个有效样本以后状态错误锁存，必须重新启动任务。静止且无可见跳变、设备时间戳又不变的外部复位不能由软件保证检测到，任务中必须禁止设备 Reset。

`age` 是主机接收年龄及已知 DVL 速度处理时间的下界，不包含尚未测定的网络及位姿延迟。速度采样/发送时间戳已保留，并检查重放、倒退、内部处理延迟及 DVL 位姿/速度采样偏差。当前报文来源没有被证明共享采样时钟；日志明确记录这一限制。实际核验时需要测量 DVL/飞控延迟及偏差，不能把“同一时刻收到”当作“同一时刻采样”。`state.frame_verified=false` 因此保持默认，不能为了启动而跳过核验。

T200 曲线和推力方向

来源：[官方产品](https://bluerobotics.com/store/thrusters/t100-t200-thrusters/t200-thruster-r2-rp/)，[官方原始 Excel](https://cad.bluerobotics.com/T200-Public-Performance-Data-10-20V-September-2019.xlsx)。本地 XLSX SHA256：`1399b76df7a176cfbb08760c11731199053336e7d92182dece11824c73285085`。

实际核对的工作表为 `READ ME FIRST` 和 `10 V`、`12 V`、`14 V`、`16 V`、`18 V`、`20 V`，各 201 个 1100～1900 μs、4 μs 间隔点。列名为 PWM (µs)、RPM、Current (A)、Voltage (V)、Power (W)、Force (Kg f)、Efficiency (g/W)，推力乘 `9.80665` 转 N。

文件“READ ME FIRST”的正文在 Excel 绘图文本中，预处理实际读取 `xl/drawings/drawing1.xml`：单个 2019 年 8 月 T200，Basic ESC R3，原始设置 BlHeli_S 16.6，静态系泊、零入口速度；ESC 电源端远端采样消除电源线压降；每个 PWM 启动 1.5 s 后采 2 s、10 Hz 共20点求均值，再休息30 s；小于300 RPM的数据置零。完整测试条件保存在 JSON `source_notes`。这是官方静态近似，**不是本机实测推力反馈**。

预处理与反查规则：

1. 正反向独立处理，保留官方不对称数据。按 PWM 离开中立的顺序对力幅值做等权 PAVA 单调回归；各表最大调整量已保存，约0～0.067 N。
2. 零力始终为1500 μs；正反向死区的零力锚点位于对应死区外沿。重复非零力选离中立最近的 PWM，使反查确定。
3. 先在相同 PWM 上按实际电压线性插值力曲线，再对相应支路逐段反查 PWM。舍入到整数 μs，并记录该量化 PWM 的官方静态估计力。
4. 电压限制10～20 V，无范围外推；推力超过该电压能力报错。输出层最多容忍0.05 N边界舍入裁剪，单独记录请求力/采用力/硬件饱和；算法原有限幅仍由原执行器计算。
5. 零推力清理不依赖电压，仍可在电压遥测失效后回中。非零力优先新鲜 `SYS_STATUS`，其次 `BATTERY_STATUS[0]` 有效电芯电压求和。没有遥测时仅允许显式 `output.test_voltage_v`，日志写 `configured_test_voltage`，默认 null。

`T200.thrust_to_pwm(force_n, voltage_v, thruster_id)` 中 `thruster_id` 为原厂推进器号。输出接口 `send_thruster_forces(forces_n)` 的六元素顺序是模型输入顺序；`send_thruster_pwm(pwm_us)` 的六元素顺序是**物理 MAIN1～MAIN6**。映射集中在 JSON 中，不散落编号。配置中的 `model_signature` 绑定该映射所对应的模型几何/推力限值；模型变化时不能继续沿用旧映射核验。

| 模型索引（从0） | 原厂编号 | 实测配置输出 | 候选 model→curve 符号 |
|---|---|---|---|
| 0 | 1 | MAIN1 / SERVO1_FUNCTION=33 | -1 |
| 1 | 2 | MAIN2 / 34 | -1 |
| 2 | 3 | MAIN3 / 35 | +1 |
| 3 | 4 | MAIN4 / 36 | +1 |
| 4 | 5 | MAIN5 / 37 | -1 |
| 5 | 6 | MAIN6 / 38 | +1 |

这些符号来自本轮读到的 `MOT_*_DIRECTION`，只作为候选。原混控的方向设置不能证明“模型正力方向=实机方向”，模型中1/3横向位置符号还与starboard标签冲突。专用路径直接写物理 PWM，故意绕过 `MOT_DIRECTION`、混控及 servo 缩放；最终必须逐路测量实际作用力方向再更新配置并设置 `channel_mapping_verified=true`。本次没有改动模型几何来掩盖问题。若需修正模型/重新规划，先确认算法行为变化。

时序和停止

区间开始按原代码计算：`error=x_hat-x_bar`，姿态三个分量 `atan2(sin(error),cos(error))`；`feedback=-K@error`；`force=clip(f_bar+feedback, model.thrust_min, model.thrust_max)`。不重新计算 K，不添加噪声，不再使用规划 Kalman gain 更新融合状态。

按轨迹自身 `time[k]` 等待。默认起始迟到超过25 ms终止；即使没超过25 ms，只要已经越过该区间末端也终止。不得快速补历史指令。持有期间每5 ms轮询状态/通信，40 ms重发相同PWM；不重新计算反馈或根据电压变动重新映射同一区间。状态失效、心跳中断、设备/参考变化、用户信号中止等立即进入清理；主机失效则由飞控最多200 ms的到期保护回中，详见固件说明。

主机在旧 `execute_lbts_plan` 中仅增加必要执行钩子：`poll/set_interval_deadline/on_step/require_stop_confirmation`，原有回调仍可用。原来的解锁/停止函数默认会发 MANUAL_CONTROL，不能直接沿用；本入口只复用其连接、消息处理、日志及心跳识别，解锁使用相同标准 MAVLink 命令而不发手动中立。

正常/异常都先请求本会话 STOP，必须收到六路 HAL 回读1500，再请求上锁并等待**新收到的**已上锁心跳，最后 RELEASE 并收到 IDLE。任一步未确认都报告 `stop_unconfirmed`，不报告完成。HAL readback只是飞控驱动端证据，不是电气测量或物理推力。原执行器的 `completed` 被命令入口写成 `sequence_completed`；`tracking_success=null`，不据时序完成自动判跟踪成功。

主机锁文件拒绝第二个新执行器；飞控租约期间隔离旧 goto、trajectory、摇杆、GUIDED/姿态目标、servo/motor test和参数写入。ACQUIRE 要求已上锁且最近1秒无旧输入，因此不会自动接管活跃控制器。操作时仍应先停掉旧程序和QGC摇杆输出；QGC可保留只读遥测。正常退出后恢复旧入口。没有使用“六路力→四轴MANUAL_CONTROL”的替代方案。

实验日志

复用 `SessionLogger` 写 JSONL/CSV，原始消息与附加事件在 `logs/force/`：

- `control_step`：计划/实际时间、完整标称和实测状态、分量年龄/时间戳、误差、标称力、反馈修正、限幅前力、算法限幅后力和饱和。
- `force_mapping`：请求力、硬件采用力、量化PWM对应的官方静态估计力、发送PWM、电压及来源、硬件饱和、发送序号和主机时间。
- `pwm_frame`：包括保持重发的完整六路、序号、飞控到期时刻；`driver_readback`：应答序号、实际HAL回读、状态及接收时刻。
- `stop`：退出原因与停止确认，明确 `physical_thrust_confirmed=false`。

命令 `--output` 保存汇总 JSON；有控制步记录时保存同名 `.error.png`、`.output.png`。发送PWM与驱动端回读分别命名，不把发包成功当成推力实现。无需网页。

从六路PWM到短轨迹的操作顺序

1. 先读 `reports/verification_live_final.json` 和 `firmware/ardusub_3_5_4/README_zh.md`。本轮读到3.5.4，已上锁MANUAL，六路1100/1500/1900范围，普通PWM，输出中立，最终只读电压15.960 V，DVL连接与有效报文已恢复。最新证据见 `reports/verification_live_final.json`。只读复核命令：`python3 tools/diagnose_direct6.py`，它不切模式、不解锁、不写参数。
2. 在隔离源码区按精确版本应用补丁，完成SITL/对应板卡构建、接口路由/完整六路/看门狗/停止回读核验。**不自动刷写。** 未完成前保持 `firmware_verified=false`。完整 SITL 已编译并通过11项联测；对应真实板卡构建和部署、电气输出测量尚未完成。
3. 停止旧输出入口，保持飞控已上锁MANUAL。完成固件测量后设置 `firmware_verified=true`。先执行全1500的0.5秒PWM测试，验证退出时有中立、上锁和释放证据，再在适合推进器运行的水中逐个测试小幅±PWM，确认1～6编号、作用力方向和通道对应。
4. 将实际核验结果写入唯一 `mapping`，再设置 `output.channel_mapping_verified=true`。核实模型几何冲突；如确实要改原模型，先确认影响，本次未修改。核验兼容后才设置 `model_geometry_compatible_verified=true`。
5. A50链路已恢复；沿用已保存参考，不重复建立水面原点；核实姿态基准、sensor/world速度属性、安装旋转、杆臂及状态延迟。设置真实 `state` 参数并在核验后设置 `frame_verified=true`。任务中不复位设备和参考文件。
6. 使用原规划器生成该固定坐标内、起点接近当前状态的短计划；`save_force_plan` 导出，离线检查。显式一次 `plan ... --execute` 完成预检、解锁、时序执行、回中和上锁，发生异常不自动重试。
7. 分开验收输出与跟踪：先依据完整帧、HAL回读及实际测量确认独立输出；再用记录的状态、误差和图评价轨迹结果。系统显示 `sequence_completed` 仅表示时序完成，不能作为跟踪成功。

算法对齐与本轮实际测试

`reports/matlab_alignment.json` 和配套 `.input.mat/.reference.mat` 保存固定输入、原 `.m` 输出、源文件SHA256和误差。原始MATLAB是Heavy八推进器，不能当六推进器已移植版本；测试分别比较原八路模型以及把同一六路几何注入通用`.m`动力学的结果。对原有限差分函数的三处写死8维只在临时测试副本中替换为 `numel(u)`，不改原文件和运算。

已比较每种模型24组非零姿态/速度/推力的动力学与RK4，Jacobian，三个非等间隔区间的Riccati增益/Joseph协方差传播和代价，六路姿态包络/饱和反馈，以及原反向Dijkstra。六路动力学最大绝对误差约 `8.88e-16`、RK4 `5.55e-17`、反馈增益 `8.16e-10`；反馈运算与姿态误差结果在测试输入下相同。

差异：原 MATLAB `chanceCollisionProbability.m` 在正定位置协方差时用Cholesky生成样本，Python始终用特征分解。共享同一个200点Z时分布等价，有限样本位置却不同，复现实例风险Python=0.090、原.m=0.085。这可能影响靠近机会约束阈值时的边接纳/搜索结果。最小候选补丁保存在 `reports/proposed_chance_alignment.patch`，**没有应用**。需要用户确认后才修改原算法并重新验证，不能声称Python已经全部对齐。

重新运行对齐（安装Octave或使用本地MATLAB；无需机器人）：

```bash
python3 tools/verify_matlab_alignment.py --engine octave
# 或
python3 tools/verify_matlab_alignment.py --engine matlab --executable /实际路径/matlab
```

存在差异时脚本退出码2是预期的差异报告，不是掩盖失败。当前结果来自临时解包的Octave6.4.0，不修改系统安装；并未运行MATLAB本体。完整OCP、采样搜索和MATLAB CasADi数值对齐仍待适配环境。软件和原生固件核心测试：

```bash
python3 -m pytest -q
(cd .. && python3 -m pytest -q tests)
```

以 `reports/test_results.txt` 为本轮实际结果。仍待实机/SITL的项目：完整补丁构建、板卡输出同步/看门狗测量、Companion专用消息路由、通道推力符号、DVL完整状态/坐标/时间、物理跟踪。没有自动驱动机器人、升级飞控或修改持久配置。
